Four article sets, focused on economy, politics, military, and history respectivelly. For instance, they can be used to extract topic signatures for the 4 topic.

Topic:           Economy           Politics               Military          History
Number of Docs:  194               231                    206               194
Number of Sents: 4150              3334                   3782              9528
Sources:         CNN, Xinhua       Xinhua,WhiteHouse      MND[1],DOD[2]     CASS[3],History(UK)[4]
[1]The Ministry of National Defense, PRC.
[2]U.S. Defense Ministry.
[3]http://jds.cass.cn/
[4]http://www.history.co.uk/


Please cite:
@article{lin2014topic-focused,
title={Topic-Focused Summarization of News Events Based on Biased Snippet Extraction and Selection},
author={pingping lin,shize xu,yan zhang},
year={2014}}