Four news article sets, focused on Diaoyu islands, U.S government shutdown, Syria crisis, and Edward Snowden's leaks respectivelly.

There are 5 news source as shown below:
News Source     &    Region:
CNN                  US
SCMP 		     Hong Kong
BBC 		     UK
Xinhua 		     China
Japan Daily Press    Japan

Details of the 4 news ariticles sets:
News Subject:    Diaoyu Islands               Edward Snowden             2013 US government shutdown       Syria crisis
Number of Docs:  502                          993                        630                               884
Number of Sents: 9405                         24687                      21851                             21851
Time Interval:   Oct, 2013 - Dec, 2013        Jun, 2013 - Aug, 2013      Sep, 2013 - Nov, 2013             Sep, 2013 - Dec, 2013


Please cite:
@article{lin2014topic-focused,
title={Topic-Focused Summarization of News Events Based on Biased Snippet Extraction and Selection},
author={pingping lin,shize xu,yan zhang},
year={2014}}